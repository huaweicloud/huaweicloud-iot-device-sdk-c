var searchData=
[
  ['quality_20of_20service_700',['Quality of service',['../qos.html',1,'']]]
];
